const STORAGE_KEYS = {
  MUTUAL: 'mutual',
  FIREBASE_ENABLED: 'firebaseEnabled',
  FIREBASE_CONFIG: 'firebaseConfig',
  CUSTOM_DOMAINS: 'customDomains'
};
const THEME_KEY = 'locusfocus_theme';
function saveLocal(obj) { return chrome.storage.local.set(obj); }
function getLocal(keys) { return chrome.storage.local.get(keys); }
function el(id) { return document.getElementById(id); }
function send(msg) { return new Promise(resolve => chrome.runtime.sendMessage(msg, resolve)); }

async function load() {
  const storedTheme = localStorage.getItem(THEME_KEY) || 'light';
  applyTheme(storedTheme);
  document.querySelectorAll('.theme-btn').forEach(btn => {
    btn.addEventListener('click', () => applyTheme(btn.dataset.themeValue));
  });

  const data = await getLocal([STORAGE_KEYS.MUTUAL, STORAGE_KEYS.FIREBASE_CONFIG, STORAGE_KEYS.FIREBASE_ENABLED]);
  const mutual = data[STORAGE_KEYS.MUTUAL] || {};
  el('userId').value = mutual.userId || '';
  el('roomId').value = mutual.roomId || '';
  el('mutualEnabled').checked = !!mutual.enabled;
  
  const cfg = data[STORAGE_KEYS.FIREBASE_CONFIG] || {};
  ['apiKey','authDomain','projectId','appId'].forEach(k => el(k).value = cfg[k] || '');
  
  const domainsRes = await send({ type: 'GET_DOMAINS' });
  if (domainsRes?.ok) {
    el('domains-list').value = domainsRes.domains.join('\n');
  }
  
  // Check if Ultra Lock is active or locked by partner
  const state = await send({ type: 'GET_STATE' });
  const lockStatus = await send({ type: 'GET_LOCK_STATUS' });
  const ulNow = Date.now();
  const ultraActive = state.ultraLockUntil && ulNow < state.ultraLockUntil;
  const lockedByPartner = lockStatus?.lockedBy && !lockStatus?.canUnlock;
  
  if (ultraActive || lockedByPartner) {
    // Disable domain editing during Ultra Lock or partner lock
    el('domains-list').disabled = true;
    el('save-domains').disabled = true;
    el('reset-domains').disabled = true;
    el('domains-list').style.opacity = '0.5';
    el('domains-list').style.cursor = 'not-allowed';
    
    if (ultraActive) {
      const remain = Math.ceil((state.ultraLockUntil - ulNow) / 60000);
      el('domains-status').textContent = `Cannot edit during Ultra Lock (${remain} min remaining)`;
    } else {
      el('domains-status').textContent = `Cannot edit while locked by partner`;
    }
    el('domains-status').style.color = '#d70015';
  }
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem(THEME_KEY, theme);
  document.querySelectorAll('.theme-btn').forEach(btn => {
    btn.classList.toggle('is-active', btn.dataset.themeValue === theme);
  });
}
async function save() {
  const mutual = {
    enabled: el('mutualEnabled').checked,
    userId: el('userId').value.trim(),
    roomId: el('roomId').value.trim()
  };
  await saveLocal({ [STORAGE_KEYS.MUTUAL]: mutual });
  
  const cfg = {
    apiKey: el('apiKey').value.trim(),
    authDomain: el('authDomain').value.trim(),
    projectId: el('projectId').value.trim(),
    appId: el('appId').value.trim()
  };
  const firebaseEnabled = !!(cfg.apiKey && cfg.projectId && cfg.appId);
  await saveLocal({ [STORAGE_KEYS.FIREBASE_CONFIG]: cfg, [STORAGE_KEYS.FIREBASE_ENABLED]: firebaseEnabled });
  
  await chrome.runtime.sendMessage({ type: 'SAVE_MUTUAL_SETTINGS', payload: { ...mutual, firebaseEnabled } });
  el('save-status').textContent = 'Saved.';
  setTimeout(() => { el('save-status').textContent = ''; }, 3000);
}
async function testConnection() {
  try {
    el('save-status').textContent = 'Testing Firebase connection...';
    const mod = await import('./firebase.js');
    const fb = await mod.initFirebase();
    const db = fb.firestore;
    const testDoc = db.collection('socialShieldRooms').doc('__test__');
    await testDoc.set({ ping: Date.now() }, { merge: true });
    const got = await testDoc.get();
    el('save-status').textContent = got.exists ? 'Firebase connected ✅' : 'Firebase write failed';
  } catch (e) {
    console.error(e);
    el('save-status').textContent = 'Firebase error. Check your config and Firestore rules.';
  }
}

async function saveDomains() {
  // Check if Ultra Lock is active or locked by partner
  const state = await send({ type: 'GET_STATE' });
  const lockStatus = await send({ type: 'GET_LOCK_STATUS' });
  const ulNow = Date.now();
  const ultraActive = state.ultraLockUntil && ulNow < state.ultraLockUntil;
  const lockedByPartner = lockStatus?.lockedBy && !lockStatus?.canUnlock;
  
  if (ultraActive || lockedByPartner) {
    el('domains-status').textContent = ultraActive 
      ? 'Cannot save domains during Ultra Lock.' 
      : 'Cannot save domains while locked by partner.';
    el('domains-status').style.color = '#d70015';
    return;
  }
  
  const text = el('domains-list').value;
  const domains = text.split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0 && !line.startsWith('#'));
  
  if (domains.length === 0) {
    el('domains-status').textContent = 'Please enter at least one domain.';
    return;
  }
  
  const res = await send({ type: 'SAVE_DOMAINS', domains });
  if (res?.ok) {
    el('domains-status').textContent = `Saved ${domains.length} domains.`;
    el('domains-status').style.color = '#059669';
  } else {
    el('domains-status').textContent = 'Failed to save domains.';
  }
}

async function resetDomains() {
  // Check if Ultra Lock is active or locked by partner
  const state = await send({ type: 'GET_STATE' });
  const lockStatus = await send({ type: 'GET_LOCK_STATUS' });
  const ulNow = Date.now();
  const ultraActive = state.ultraLockUntil && ulNow < state.ultraLockUntil;
  const lockedByPartner = lockStatus?.lockedBy && !lockStatus?.canUnlock;
  
  if (ultraActive || lockedByPartner) {
    el('domains-status').textContent = ultraActive 
      ? 'Cannot reset domains during Ultra Lock.' 
      : 'Cannot reset domains while locked by partner.';
    el('domains-status').style.color = '#d70015';
    return;
  }
  
  await chrome.storage.local.remove(STORAGE_KEYS.CUSTOM_DOMAINS);
  const domainsRes = await send({ type: 'GET_DOMAINS' });
  if (domainsRes?.ok) {
    el('domains-list').value = domainsRes.domains.join('\n');
    el('domains-status').textContent = 'Reset to default domains.';
    el('domains-status').style.color = '#059669';
  }
}

document.getElementById('save').addEventListener('click', save);
document.getElementById('test').addEventListener('click', testConnection);
document.getElementById('save-domains').addEventListener('click', saveDomains);
document.getElementById('reset-domains').addEventListener('click', resetDomains);
load();
