import { SOCIAL_DOMAINS } from './social_domains.js';

const STORAGE_KEYS = {
  BLOCK_ENABLED: 'blockEnabled',
  ULTRA_LOCK_UNTIL: 'ultraLockUntil',
  MUTUAL: 'mutual',
  FIREBASE_ENABLED: 'firebaseEnabled',
  CUSTOM_DOMAINS: 'customDomains',
  LOCKED_BY: 'lockedBy'
};

const RULESET_ID = 20000;

async function getActiveDomains() {
  const { [STORAGE_KEYS.CUSTOM_DOMAINS]: customDomains } = await chrome.storage.local.get(STORAGE_KEYS.CUSTOM_DOMAINS);
  if (customDomains && Array.isArray(customDomains) && customDomains.length > 0) {
    return customDomains;
  }
  return SOCIAL_DOMAINS;
}

function buildRules() {
  let id = RULESET_ID;
  return SOCIAL_DOMAINS.map(domain => ({
    id: id++,
    priority: 1,
    action: { type: 'redirect', redirect: { extensionPath: '/blocked.html' } },
    condition: { urlFilter: `||${domain}^`, resourceTypes: ["main_frame", "sub_frame"] }
  }));
}

async function buildRulesFromDomains(domains) {
  let id = RULESET_ID;
  return domains.map(domain => ({
    id: id++,
    priority: 1,
    action: { type: 'redirect', redirect: { extensionPath: '/blocked.html' } },
    condition: { urlFilter: `||${domain}^`, resourceTypes: ["main_frame", "sub_frame"] }
  }));
}

async function enableBlocking() {
  const domains = await getActiveDomains();
  const rules = await buildRulesFromDomains(domains);
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: rules.map(r => r.id),
    addRules: rules
  });
}

async function disableBlocking() {
  const domains = await getActiveDomains();
  const rules = await buildRulesFromDomains(domains);
  const ids = rules.map(r => r.id);
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: ids });
}

async function isUltraLocked(now = Date.now()) {
  const { [STORAGE_KEYS.ULTRA_LOCK_UNTIL]: until } = await chrome.storage.local.get(STORAGE_KEYS.ULTRA_LOCK_UNTIL);
  return typeof until === 'number' && now < until;
}

async function getState() {
  const data = await chrome.storage.local.get(Object.values(STORAGE_KEYS));
  return {
    blockEnabled: !!data[STORAGE_KEYS.BLOCK_ENABLED],
    ultraLockUntil: data[STORAGE_KEYS.ULTRA_LOCK_UNTIL] || null,
    mutual: data[STORAGE_KEYS.MUTUAL] || { enabled: false },
    firebaseEnabled: !!data[STORAGE_KEYS.FIREBASE_ENABLED]
  };
}

async function setBlockEnabled(enabled) {
  await chrome.storage.local.set({ [STORAGE_KEYS.BLOCK_ENABLED]: enabled });
  if (enabled) await enableBlocking(); else await disableBlocking();
}

chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name === 'ultra-lock-check') {
    if (!(await isUltraLocked())) {
      await chrome.storage.local.set({ [STORAGE_KEYS.ULTRA_LOCK_UNTIL]: null });
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'Ultra Lock finished',
        message: 'You\'re free! Social sites are no longer forcibly locked.'
      });
      chrome.alarms.clear('ultra-lock-check');
    }
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (msg.type === 'GET_STATE') {
      const state = await getState();
      state.effectiveLocked = await computeEffectiveLocked(state);
      sendResponse(state);
    }
    if (msg.type === 'GET_DOMAINS') {
      const domains = await getActiveDomains();
      sendResponse({ ok: true, domains });
    }
    if (msg.type === 'SAVE_DOMAINS') {
      const { domains } = msg;
      await chrome.storage.local.set({ [STORAGE_KEYS.CUSTOM_DOMAINS]: domains });
      const state = await getState();
      if (state.blockEnabled) {
        await disableBlocking();
        await enableBlocking();
      }
      sendResponse({ ok: true });
    }
    if (msg.type === 'TOGGLE_BLOCK') {
      const state = await getState();
      if (await isUltraLocked()) { sendResponse({ ok: false, reason: 'ULTRA_LOCK_ACTIVE' }); return; }
      const next = !state.blockEnabled;
      await setBlockEnabled(next);
      sendResponse({ ok: true, blockEnabled: next });
    }
    if (msg.type === 'START_ULTRA_LOCK') {
      const { minutes } = msg;
      const until = Date.now() + Math.max(1, minutes) * 60 * 1000;
      await chrome.storage.local.set({ [STORAGE_KEYS.ULTRA_LOCK_UNTIL]: until });
      await setBlockEnabled(true);
      chrome.alarms.create('ultra-lock-check', { delayInMinutes: 1, periodInMinutes: 1 });
      sendResponse({ ok: true, until });
    }
    if (msg.type === 'CANCEL_ULTRA_LOCK') { sendResponse({ ok: false, reason: 'CANNOT_CANCEL_ULTRA_LOCK' }); }
    if (msg.type === 'SAVE_MUTUAL_SETTINGS') {
      const { enabled, userId, roomId, firebaseEnabled } = msg.payload;
      await chrome.storage.local.set({
        [STORAGE_KEYS.MUTUAL]: { enabled, userId, roomId },
        [STORAGE_KEYS.FIREBASE_ENABLED]: !!firebaseEnabled
      });
      if (firestore) {
        firestore = null;
        fb = null;
      }
      if (enabled && firebaseEnabled) {
        await ensureFirebase();
      }
      sendResponse({ ok: true });
    }
    if (msg.type === 'MUTUAL_REQUEST_LOCK') { const ok = await mutualRequestLock(); sendResponse({ ok }); }
    if (msg.type === 'MUTUAL_REQUEST_UNLOCK') { 
      const res = await mutualRequestUnlock(msg.targetUserId); 
      sendResponse(res); 
    }
    if (msg.type === 'GET_LOCK_STATUS') {
      const { lockedBy, mutual } = await chrome.storage.local.get([STORAGE_KEYS.LOCKED_BY, 'mutual']);
      sendResponse({ lockedBy, canUnlock: !lockedBy || lockedBy === mutual?.userId });
    }
  })();
  return true;
});

let firestore = null;
let fb = null;

async function ensureFirebase() {
  const { [STORAGE_KEYS.FIREBASE_ENABLED]: firebaseEnabled } = await chrome.storage.local.get(STORAGE_KEYS.FIREBASE_ENABLED);
  if (!firebaseEnabled) return null;
  if (firestore) return firestore;
  try {
    const mod = await import('./firebase.js');
    fb = await mod.initFirebase();
    firestore = fb.firestore;
    startMutualListener();
    return firestore;
  } catch (e) {
    console.error('Firebase init failed', e);
    return null;
  }
}

function roomDoc(db, roomId) { return db.collection('socialShieldRooms').doc(roomId); }

async function handlePartnerLockChange(data) {
  if (data.type === 'unlock' && data.targetUserId) {
    const { mutual } = await chrome.storage.local.get('mutual');
    if (data.targetUserId === mutual?.userId) {
      await chrome.storage.local.set({ [STORAGE_KEYS.LOCKED_BY]: null });
      await setBlockEnabled(false);
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'Unlocked by partner',
        message: `${data.userId} has unlocked your access.`
      });
    }
  } else if (data.locked && data.targetUserId) {
    const { mutual } = await chrome.storage.local.get('mutual');
    if (data.targetUserId === mutual?.userId) {
      await chrome.storage.local.set({ [STORAGE_KEYS.LOCKED_BY]: data.userId });
      await setBlockEnabled(true);
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'Locked by partner',
        message: `${data.userId} has locked your social media access.`
      });
    }
  }
}

async function mutualRequestLock() {
  const db = await ensureFirebase();
  if (!db) return false;
  
  const { mutual } = await chrome.storage.local.get('mutual');
  if (!mutual?.roomId || !mutual?.userId) return false;
  
  const doc = roomDoc(db, mutual.roomId);
  
  // Lock yourself
  await chrome.storage.local.set({ [STORAGE_KEYS.LOCKED_BY]: mutual.userId });
  await setBlockEnabled(true);
  
  await doc.set({ 
    lastUpdated: Date.now(), 
    locks: { 
      [mutual.userId]: {
        locked: true,
        lockedBy: mutual.userId,
        targetUserId: mutual.userId,
        timestamp: Date.now()
      }
    } 
  }, { merge: true });
  
  return true;
}

async function mutualRequestUnlock(targetUserId) {
  const db = await ensureFirebase();
  if (!db) return false;
  
  const { mutual, lockedBy } = await chrome.storage.local.get(['mutual', STORAGE_KEYS.LOCKED_BY]);
  if (!mutual?.roomId || !mutual?.userId) return false;
  
  const doc = roomDoc(db, mutual.roomId);
  
  // If trying to unlock someone else
  if (targetUserId && targetUserId !== mutual.userId) {
    await doc.set({ 
      lastUpdated: Date.now(), 
      locks: { 
        [targetUserId]: {
          locked: false,
          lockedBy: mutual.userId,
          targetUserId: targetUserId,
          type: 'unlock',
          timestamp: Date.now()
        }
      } 
    }, { merge: true });
    return { ok: true };
  }
  
  // Can't unlock yourself if locked by partner
  if (lockedBy && lockedBy !== mutual.userId) {
    return { ok: false, reason: 'LOCKED_BY_PARTNER' };
  }
  
  // Unlock yourself
  await chrome.storage.local.set({ [STORAGE_KEYS.LOCKED_BY]: null });
  await setBlockEnabled(false);
  
  await doc.set({ 
    lastUpdated: Date.now(), 
    locks: { 
      [mutual.userId]: {
        locked: false,
        lockedBy: mutual.userId,
        targetUserId: mutual.userId,
        timestamp: Date.now()
      }
    } 
  }, { merge: true });
  
  return { ok: true };
}

async function computeEffectiveLocked(state) {
  const ultra = await isUltraLocked();
  return ultra || state.blockEnabled;
}

function startMutualListener() {
  chrome.storage.local.get('mutual', async ({ mutual }) => {
    if (!mutual?.roomId || !firestore) return;
    
    const doc = roomDoc(firestore, mutual.roomId);
    doc.onSnapshot(async (snap) => {
      const data = snap.data() || {};
      const locks = data.locks || {};
      
      // Check if partner locked/unlocked us
      const myLock = locks[mutual.userId];
      if (myLock && myLock.lockedBy !== mutual.userId) {
        await handlePartnerLockChange(myLock);
      }
    });
  });
}

chrome.runtime.onInstalled.addListener(async () => {
  const initial = await getState();
  if (initial.blockEnabled) await enableBlocking();
  if (initial.mutual?.enabled) await ensureFirebase();
});
